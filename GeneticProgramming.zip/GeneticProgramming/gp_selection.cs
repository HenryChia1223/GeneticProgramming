﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GeneticProgramming
{
    class gp_selection
    {
        public static void selection(Dictionary<string,int> dic)
        {

        } 
    }
}
